const { validationResult } = require("express-validator");

// Put AFTER the express-validator rules and BEFORE the controller.
function validateRequest(req, res, next) {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({
      message: "Validation failed",
      errors: errors.array().map((error) => ({
        field: error.path,
        message: error.msg
      }))
    });
  }

  next();
}

module.exports = validateRequest;