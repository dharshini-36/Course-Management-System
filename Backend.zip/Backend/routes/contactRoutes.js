const express = require("express");
const User = require("../models/User");

// IMPORTANT: use the SAME auth import line that Backend/routes/messageRoutes.js uses.
const { authenticate: requireAuth } = require("../middleware/authMiddleware");

const router = express.Router();

// GET /api/v1/contacts
// Students get the list of admins. Admins get the list of students.
router.get("/", requireAuth, async (req, res, next) => {
  try {
    const myId = String(req.user.id || req.user._id || req.user.userId);

    // Read my role from the database instead of trusting the token's casing.
    const me = await User.findById(myId).select("role").lean();
    const iAmAdmin = String(me?.role || req.user.role || "").toLowerCase() === "admin";

    const users = await User.find({ _id: { $ne: myId } })
      .select("name fullName email role")
      .sort({ name: 1 })
      .lean();

    const contacts = users
      .filter((user) => {
        const isAdmin = String(user.role || "").toLowerCase() === "admin";
        return iAmAdmin ? !isAdmin : isAdmin;
      })
      .map((user) => ({
        _id: String(user._id),
        name: user.name || user.fullName || user.email,
        role: String(user.role || "").toLowerCase() === "admin" ? "admin" : "student",
      }));

    // Debug line: shows in the backend terminal. Remove once it works.
    console.log(
      `[contacts] me=${myId} role=${me?.role} -> ${users.length} other users, ${contacts.length} contacts. Roles in DB:`,
      [...new Set(users.map((u) => u.role))]
    );

    res.json({ contacts });
  } catch (error) {
    next(error);
  }
});

module.exports = router;